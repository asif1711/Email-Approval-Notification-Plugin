<?php
/**
 * Plugin Name: Digital Logbook
 * Description: Turns user data into digital logbooks.
 * Version: 0.1.0
 */

function dl_resolve_enrollment_no() {
    // 🔧 TEMP: fixed enrollment for ACC testing
    return 'ENR-TEST-001';
}


function dl_resolve_student_email_by_enrollment($enrollment_no) {

    global $wpdb;

    if (empty($enrollment_no)) {
        return null;
    }

    return $wpdb->get_var(
        $wpdb->prepare(
            "SELECT email
             FROM {$wpdb->prefix}acc_students
             WHERE enrollment_no = %s",
            $enrollment_no
        )
    );
}

if (!defined('ABSPATH')) {
    exit;
}

// Load notification runner
require_once __DIR__ . '/includes/send-manager-emails.php';
require_once __DIR__ . '/includes/send-student-notifications.php';


add_action('init', function () {

    if (!isset($_GET['dl_test_pdf_email'])) {
        return;
    }

    require_once __DIR__ . '/email/EmailService.php';

    // 🔁 CHANGE THIS to a REAL PDF PATH you already generate
    $pdf_path = WP_CONTENT_DIR . '/uploads/logbooks/logbook-1770372663.pdf';

	if (!file_exists($pdf_path)) {
		wp_die('PDF NOT FOUND: ' . $pdf_path);
	}

    $email = new DL_EmailService();

    $sent = $email->send_with_pdf(
        'manager@test.local',
        'Logbook Submission – PDF Attached',
        '<p>Please find the attached logbook PDF for review.</p>',
        $pdf_path
    );

    wp_die($sent ? 'PDF email sent. Check Mailpit.' : 'Failed to send PDF email.');
});

add_filter('the_content', function ($content) {

    if (!is_page('logbook-approval')) {
        return $content;
    }

    global $wpdb;
    $table = $wpdb->prefix . 'cf7_pdf_logs';

    $token  = $_GET['token']  ?? '';
    $action = $_GET['action'] ?? '';

    if ($token === '' || !in_array($action, ['approve', 'reject'], true)) {
        return '<p>Invalid approval request.</p>';
    }

    // Fetch matching logbook
    $log = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM {$table}
             WHERE approval_token = %s",
            $token
        )
    );

    if (!$log) {
        return '<p>This approval link is invalid or has already been used.</p>';
    }

    // Check expiry
    if (
        $log->approval_token_expires_at &&
        strtotime($log->approval_token_expires_at) < time()
    ) {
        return '<p>This approval link has expired.</p>';
    }

    // Prevent double action
    if ($log->approval_status !== 'pending') {
        return '<p>This logbook has already been processed.</p>';
    }

    // Determine new status
    $new_status = ($action === 'approve') ? 'approved' : 'rejected';

    // Update DB atomically
    $wpdb->update(
        $table,
        [
            'approval_status' => $new_status,
            'approved_at'     => current_time('mysql'),
            'approval_token'  => null,
            'approval_token_expires_at' => null,
        ],
        ['id' => $log->id],
        ['%s', '%s', '%s', '%s'],
        ['%d']
    );

    // Response message
    if ($new_status === 'approved') {
        return '<h2>Logbook Approved</h2><p>The logbook has been successfully approved.</p>';
    }

    return '<h2>Logbook Rejected</h2><p>The logbook has been rejected.</p>';

});
