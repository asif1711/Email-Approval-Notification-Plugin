<?php
if (!defined('ABSPATH')) {
    exit;
}

class DL_EmailService {

	/**
	 * Send HTML email without attachment
	 *
	 * @param string $to
	 * @param string $subject
	 * @param string $message (HTML)
	 * @return bool
	 */
	public function send_html($to, $subject, $message) {

		$this->configure_mailer();

		if (empty($to)) {
			return false;
		}

		$headers = [
			'Content-Type: text/html; charset=UTF-8'
		];

		return wp_mail($to, $subject, $message, $headers);
	}

    /**
     * Configure SMTP (Mailpit for local)
     */
    private function configure_mailer() {
        add_action('phpmailer_init', function ($phpmailer) {
            $phpmailer->isSMTP();
            $phpmailer->Host = '127.0.0.1';
            $phpmailer->Port = 1025;
            $phpmailer->SMTPAuth = false;
        });
    }

    /**
     * Send submission email with PDF attachment
     *
     * @param string $to
     * @param string $subject
     * @param string $message (HTML)
     * @param string $pdf_path (absolute path)
     * @return bool
     */
    public function send_with_pdf($to, $subject, $message, $pdf_path) {

        $this->configure_mailer();

        // Safety check
        if (!file_exists($pdf_path)) {
            error_log('DL_EmailService: PDF not found - ' . $pdf_path);
            return false;
        }

        $headers = [
            'Content-Type: text/html; charset=UTF-8'
        ];

        $attachments = [$pdf_path];

        return wp_mail($to, $subject, $message, $headers, $attachments);
    }
}

